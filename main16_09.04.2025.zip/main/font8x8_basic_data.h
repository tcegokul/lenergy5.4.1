#ifndef FONT8X8_BASIC_DATA_H
#define FONT8X8_BASIC_DATA_H

#include <stdint.h>

extern const uint8_t font8x8_basic[128][8];

#endif
