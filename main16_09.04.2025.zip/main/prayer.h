// prayer.h
const char* prayer_get_next_name(void);
int prayer_get_current_rakah(void);
int prayer_get_current_sujood(void);
const char* prayer_get_current_posture(void);
int prayer_get_total_rakah(void);
const char** prayer_get_all_names(void);
const char** prayer_get_all_times(void);
