#ifndef _VL53L0X_DEFAULT_TUNING_SETTINGS_H_
#define _VL53L0X_DEFAULT_TUNING_SETTINGS_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

extern const uint8_t VL53L0X_DefaultTuningSettings[];

#ifdef __cplusplus
}
#endif

#endif // _VL53L0X_DEFAULT_TUNING_SETTINGS_H_
