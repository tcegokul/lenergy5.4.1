// hadiths.h
#ifndef HADITHS_H
#define HADITHS_H

#ifdef __cplusplus
extern "C" {
#endif

const char* hadiths_get_today(void);  // ✅ Doit exister

#ifdef __cplusplus
}
#endif

#endif
