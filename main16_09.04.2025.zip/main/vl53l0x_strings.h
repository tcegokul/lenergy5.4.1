#ifndef _VL53L0X_STRINGS_H_
#define _VL53L0X_STRINGS_H_

#define VL53L0X_STRING_UNKNOWN_STATE_CODE           "Unknown State"
#define VL53L0X_STRING_UNKNOWN_SEQUENCE_STEP_ID     "Unknown Sequence Step"
#define VL53L0X_STRING_UNKNOWN_LIMIT_CHECK_ID "Unknown Limit Check"

#ifndef VL53L0X_STRING_SEQUENCESTEP_TCC
#define VL53L0X_STRING_SEQUENCESTEP_TCC "TCC"
#endif

#ifndef VL53L0X_STRING_SEQUENCESTEP_DSS
#define VL53L0X_STRING_SEQUENCESTEP_DSS "DSS"
#endif


// Ajoute d'autres si besoin

#endif
