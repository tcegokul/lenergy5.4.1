#ifndef ESP_LOG_H
#define ESP_LOG_H

#include <stdio.h>

// Définir les niveaux de log
#define ESP_LOG_NONE    0
#define ESP_LOG_ERROR   1
#define ESP_LOG_WARN    2
#define ESP_LOG_INFO    3
#define ESP_LOG_DEBUG   4
#define ESP_LOG_VERBOSE 5

#ifndef LOG_LEVEL
#define LOG_LEVEL ESP_LOG_INFO  // Niveau de log par défaut
#endif

// Macros de log
#define ESP_LOGE(tag, format, ...) \
    if (LOG_LEVEL >= ESP_LOG_ERROR)   printf("[ERROR] %s: " format "\n", tag, ##__VA_ARGS__)

#define ESP_LOGW(tag, format, ...) \
    if (LOG_LEVEL >= ESP_LOG_WARN)    printf("[WARN ] %s: " format "\n", tag, ##__VA_ARGS__)

#define ESP_LOGI(tag, format, ...) \
    if (LOG_LEVEL >= ESP_LOG_INFO)    printf("[INFO ] %s: " format "\n", tag, ##__VA_ARGS__)

#define ESP_LOGD(tag, format, ...) \
    if (LOG_LEVEL >= ESP_LOG_DEBUG)   printf("[DEBUG] %s: " format "\n", tag, ##__VA_ARGS__)

#define ESP_LOGV(tag, format, ...) \
    if (LOG_LEVEL >= ESP_LOG_VERBOSE) printf("[VERBO] %s: " format "\n", tag, ##__VA_ARGS__)

#endif // ESP_LOG_H
