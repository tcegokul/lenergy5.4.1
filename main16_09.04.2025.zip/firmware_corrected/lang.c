// lang.c
#include "lang.h"
#include "config_menu.h"
#include "gps_parser.h"
#include <math.h>

static int selected_lang = -1;

static const char* lang_table[STR_COUNT][4] = {
    [STR_MENU]     = {"Menu", "القائمة", "Menu", "Menù"},
    [STR_SETTINGS] = {"Settings", "الإعدادات", "Paramètres", "Impostazioni"},
    [STR_LANGUAGE] = {"Language", "اللغة", "Langue", "Lingua"},
    [STR_BATTERY]  = {"Battery", "البطارية", "Batterie", "Batteria"},
    [STR_TIME]     = {"Time", "الوقت", "Heure", "Ora"},
    [STR_LOCATION] = {"Location", "الموقع", "Localisation", "Posizione"},
    [STR_PRAYER]   = {"Prayer", "الصلاة", "Prière", "Preghiera"},
    [STR_QIBLA]    = {"Qibla", "القبلة", "Qibla", "Qibla"},
    [STR_HADITH]   = {"Hadith", "حديث", "Hadith", "Hadith"}, 
    [STR_CHOOSE_THEME] = {"Choose a theme", "اختر موضوعًا", "Choisir un thème",   
    "Scegli un tema"},
    [STR_THEME_DESC] = {"Day / Night / Mecca / ...", "نهار / ليل / مكة / ...", "Jour / Nuit / Mecca / ...", "Giorno / Notte / Mecca / ..."},
};

static int detect_lang_from_gps() {
    float lat = gps_get_latitude();
    float lon = gps_get_longitude();

    if (lat == 0.0f && lon == 0.0f) return LANG_EN;  // pas de fix → anglais

    // France / Belgique / Suisse romande
    if (lat > 35 && lat < 49 && lon > -5 && lon < 10) return LANG_FR;

    // Italie
    if (lat > 36 && lat < 47 && lon > 6 && lon < 19) return LANG_IT;

    // Pays arabes connus (zones approximatives)
    if (
        // Maghreb
        (lat >= 19 && lat <= 37 && lon >= -17 && lon <= 11) || // Maroc, Algérie, Tunisie, Libye, Mauritanie
        // Moyen-Orient
        (lat >= 22 && lat <= 39 && lon >= 32 && lon <= 60) ||  // Égypte, Arabie Saoudite, Yémen, Oman, EAU, Qatar, Koweït
        (lat >= 29 && lat <= 37 && lon >= 35 && lon <= 42) ||  // Jordanie, Syrie, Palestine
        // Soudan & Irak
        (lat >= 12 && lat <= 23 && lon >= 22 && lon <= 37) ||  // Soudan
        (lat >= 29 && lat <= 37 && lon >= 43 && lon <= 49)     // Irak
    ) return LANG_AR;

    return LANG_EN;
}

void lang_init() {
    config_t cfg = config_get();
    if (cfg.language < 0 || cfg.language > 3) {
        cfg.language = detect_lang_from_gps();
        config_set(cfg); // on sauvegarde la langue détectée une fois
    }
    selected_lang = cfg.language;
}

int get_selected_language() {
    return selected_lang;
}

const char* translate(lang_str_id_t phrase_id) {
    if (phrase_id >= 0 && phrase_id < STR_COUNT) {
        return lang_table[phrase_id][selected_lang];
    }
    return "[?]";
}

