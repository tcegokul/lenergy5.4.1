#ifndef ICONS_H
#define ICONS_H

#include <stdint.h>

#define ICON_WIDTH  16
#define ICON_HEIGHT 16

const uint16_t icon_language[16 * 16] = { /* ton tableau RGB565 */ };


// ------------------- Prière -------------------
extern const uint16_t icon_sujood[256];            // À coder
extern const uint16_t icon_sujood_1[256];
extern const uint16_t icon_sujood_2[256];
extern const uint16_t icon_sujood_current[256];
extern const uint16_t icon_sujood_done[256];
extern const uint16_t icon_rukoo[256];             // À coder
extern const uint16_t icon_qiyam[256];             // À coder
extern const uint16_t icon_check[256];
extern const uint16_t icon_rakah_dot_active[256];
extern const uint16_t icon_rakah_dot_inactive[256];

// ------------------- Système -------------------
extern const uint16_t icon_gps_ok[256];
extern const uint16_t icon_gps_waiting[256];
extern const uint16_t icon_gps_error[256];
extern const uint16_t icon_battery_0[256];
extern const uint16_t icon_battery_25[256];
extern const uint16_t icon_battery_50[256];
extern const uint16_t icon_battery_75[256];
extern const uint16_t icon_battery_100[256];
extern const uint16_t icon_battery_charge[256];

// ------------------- Divers -------------------
extern const uint16_t icon_qibla[256];
extern const uint16_t icon_clock[256];
extern const uint16_t icon_hadith[256];
extern const uint16_t icon_night_mode[256];
extern const uint16_t icon_day_mode[256];
extern const uint16_t icon_theme[256];
extern const uint16_t icon_settings[256];
extern const uint16_t icon_home[256];
extern const uint16_t icon_bluetooth[256];

extern const uint16_t icon_language[];
extern const uint16_t icon_buzzer[];
extern const uint16_t icon_day_mode[];
extern const uint16_t icon_night_mode[];
extern const uint16_t icon_battery_25[];
extern const uint16_t icon_check[];
extern const uint16_t icon_hadith[];
extern const uint16_t icon_sujood_done[];
extern const uint16_t icon_theme[];
extern const uint16_t icon_clock[];



#endif // ICONS_H
