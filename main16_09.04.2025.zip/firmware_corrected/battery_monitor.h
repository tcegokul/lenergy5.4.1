
// battery_monitor.h
#ifndef BATTERY_MONITOR_H
#define BATTERY_MONITOR_H

#include "driver/adc.h"
#include "driver/gpio.h"
#include <stdbool.h>

void battery_monitor_init(adc_channel_t channel, gpio_num_t usb_gpio);
int battery_monitor_get_level();           // Renvoie 0–100 (%)
float battery_monitor_get_voltage();       // Renvoie tension réelle (V)
bool battery_monitor_is_charging();        // True si TP4056 CHRG = LOW
void battery_monitor_set_alert_threshold(int percent);
bool battery_monitor_is_alert_active();    // True si batterie < seuil
bool battery_is_charging(void);

#endif // BATTERY_MONITOR_H


