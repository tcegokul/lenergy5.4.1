// st7701s_display.c - Bloc 1/4

#include "st7701s_display.h"
#include "backgrounds.h"
#include "icons.h"
#include "gps_parser.h"
#include "battery.h"
#include "qibla.h"
#include "vl53l0x_sensor.h"
#include "prayer_logic.h"
#include "config_menu.h"
#include "image_manager.h"
#include "font8x8_basic.h"
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

void display_draw_text(int x, int y, const char *text, uint16_t color);
void display_draw_icon(int x, int y, const uint16_t *icon);
void display_draw_image(int x, int y, int w, int h, const uint16_t *img);
void delay_ms(int ms);

const char* get_display_time() {
    if (gps_has_fix()) return gps_get_local_time();
    time_t now; struct tm t; time(&now); localtime_r(&now, &t);
    static char fallback[6]; snprintf(fallback, sizeof(fallback), "%02d:%02d", t.tm_hour, t.tm_min); return fallback;
}

bool is_night_mode() {
    time_t now; struct tm t; time(&now); localtime_r(&now, &t); return (t.tm_hour >= 22 || t.tm_hour < 5);
}

void display_draw_status_bar() {
    display_draw_text(10, 5, get_display_time(), COLOR_WHITE);
    display_draw_icon(LCD_WIDTH - 40, 5, gps_has_fix() ? icon_gps_ok : icon_gps_waiting);
    display_draw_icon(LCD_WIDTH - 20, 5, battery_get_icon());
}

void display_home_screen() {
    const uint16_t *bg = is_night_mode() ? image_background_night_mode : image_background_mecca;
    display_draw_image(0, 0, 240, 240, bg);
    display_draw_text(80, 60, get_display_time(), COLOR_WHITE);
    display_draw_text(60, 100, gps_has_fix() ? "Paris" : "-", COLOR_YELLOW);
    display_draw_text(80, 140, prayer_get_next_name(), COLOR_GREEN);
    display_draw_status_bar();
}

void display_idle_mode() {
    const uint16_t *bg = is_night_mode() ? image_background_night_mode : image_manager_get_background(0);
    display_draw_image(0, 0, 240, 240, bg);
    display_draw_text(70, 90, get_display_time(), COLOR_WHITE);
    if (gps_has_fix()) display_draw_text(60, 130, "Paris", COLOR_YELLOW);
    display_draw_text(80, 170, prayer_get_next_name(), COLOR_GREEN);
    if (battery_is_charging()) display_draw_icon(100, 200, icon_battery_charge);
    display_draw_status_bar();
}

void display_show_prayer_state() {
    int rakah = prayer_get_current_rakah(), sujood = prayer_get_current_sujood();
    const char *posture = prayer_get_current_posture();
    const uint16_t *icon = strcmp(posture, "sujood") == 0 ? icon_sujood_current :
                          (strcmp(posture, "rukoo") == 0 ? icon_rukoo : icon_qiyam);
    display_draw_icon(100, 60, icon);
    for (int i = 0; i < prayer_get_total_rakah(); i++)
        display_draw_icon(40 + i * 20, 120, (i < rakah) ? icon_rakah_dot_active : icon_rakah_dot_inactive);
    for (int s = 0; s < 2; s++) {
        const uint16_t *suj_icon = (s < sujood) ? icon_sujood_done :
                                   (s == sujood ? icon_sujood_current : icon_sujood_1);
        display_draw_icon(100 + s * 20, 160, suj_icon);
    }
    display_draw_status_bar();
}

void display_intro_animation() {
    display_draw_image(0, 0, 240, 240, is_night_mode() ? image_background_night_mode : image_background_mecca);
    delay_ms(300);
    display_draw_text(30, 100, "\"Les actes ne valent\"", COLOR_WHITE);
    display_draw_text(30, 120, "\"que par leurs intentions.\"", COLOR_WHITE);
    display_draw_text(30, 160, "– Hadith", COLOR_GRAY);
    delay_ms(2000);
}

void display_handle_back(int btn_event) {
    if (btn_event == 3) display_home_screen();
}

void qibla_display(int btn_event) {
    display_draw_image(0, 0, 240, 240, is_night_mode() ? image_background_night_mode : image_manager_get_background(2));
    if (!gps_has_fix()) {
        display_draw_text(30, 100, "Position GPS indisponible", COLOR_RED);
        display_handle_back(btn_event);
        return;
    }

    float lat1 = gps_get_latitude() * M_PI / 180.0;
    float lon1 = gps_get_longitude() * M_PI / 180.0;
    float lat2 = 21.4225 * M_PI / 180.0;
    float lon2 = 39.8262 * M_PI / 180.0;
    float dLon = lon2 - lon1;

    float y = sin(dLon) * cos(lat2);
    float x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon);
    float bearing = atan2(y, x) * 180 / M_PI;
    if (bearing < 0) bearing += 360;

    float heading = qmi8658_get_heading();
    float angle = fmodf(bearing - heading + 360, 360);

    display_draw_text(60, 30, translate("Direction Qibla"), COLOR_YELLOW);
    display_draw_icon(112, 80, icon_qibla);

    float dlat = lat2 - lat1, dlon = lon2 - lon1;
    float a = sin(dlat/2)*sin(dlat/2) + cos(lat1)*cos(lat2)*sin(dlon/2)*sin(dlon/2);
    float distance = 6371.0 * 2 * atan2(sqrt(a), sqrt(1-a));

    char dist_str[32];
    snprintf(dist_str, sizeof(dist_str), "%s: %.1f km", translate("Distance"), distance);
    display_draw_text(40, 200, dist_str, COLOR_CYAN);
    display_draw_status_bar();
    display_handle_back(btn_event);
}

void hadith_display_today(int btn_event) {
    const uint16_t *bg = is_night_mode() ? image_background_night_mode : image_manager_get_background(3);
    display_draw_image(0, 0, 240, 240, bg);
    display_draw_icon(10, 10, icon_hadith);

    time_t now; struct tm t;
    time(&now); localtime_r(&now, &t);
    int index = t.tm_mday % 20;
    int lang = get_selected_language();

    display_draw_text(20, 60, translate("Hadith du jour"), COLOR_YELLOW);
    display_draw_text(20, 90, hadith_get_by_index(index, lang), COLOR_WHITE);
    display_draw_status_bar();
    display_handle_back(btn_event);
}

void prayer_display_times(int btn_event) {
    const uint16_t *bg = is_night_mode() ? image_background_night_mode : image_manager_get_background(4);
    display_draw_image(0, 0, 240, 240, bg);
    display_draw_text(20, 20, translate("Horaires de prière"), COLOR_YELLOW);

    const char **labels = prayer_get_all_names();
    const char **times  = prayer_get_all_times();

    for (int i = 0; i < 5; i++) {
        char line[32];
        snprintf(line, sizeof(line), "%s: %s", translate(labels[i]), times[i]);
        display_draw_text(30, 50 + i * 30, line, COLOR_WHITE);
    }
    display_draw_status_bar();
    display_handle_back(btn_event);
}

#define MENU_ITEM_COUNT 5
static const char* menu_items[MENU_ITEM_COUNT] = {
    "Themes", "Settings", "Qibla", "Prayer Times", "Hadith"
};
static int selected_item = 0;

void display_render_menu() {
    const uint16_t *background = is_night_mode() ? image_background_night_mode : image_manager_get_background(1);
    display_draw_image(0, 0, 240, 240, background);

    for (int i = 0; i < MENU_ITEM_COUNT; i++) {
        uint16_t color = (i == selected_item) ? COLOR_YELLOW : COLOR_WHITE;
        display_draw_text(30, 30 + i * 30, translate(menu_items[i]), color);
    }

    display_draw_status_bar();
}

void display_menu_interactive(int btn_event) {
    if (btn_event == 0) {
        selected_item = (selected_item - 1 + MENU_ITEM_COUNT) % MENU_ITEM_COUNT;
    } else if (btn_event == 1) {
        selected_item = (selected_item + 1) % MENU_ITEM_COUNT;
    } else if (btn_event == 2) {
        switch (selected_item) {
            case 0: config_menu_open_theme(); break;
            case 1: config_menu_open_settings(); break;
            case 2: qibla_display(btn_event); break;
            case 3: prayer_display_times(btn_event); break;
            case 4: hadith_display_today(btn_event); break;
        }
    } else if (btn_event == 3) {
        display_home_screen();  // 🔙 Retour depuis le menu
    }

    display_render_menu();
}

void config_menu_open_theme(int btn_event) {
    display_draw_image(0, 0, 240, 240, image_manager_get_background(1));
    display_draw_text(30, 30, translate("Choisir un thème"), COLOR_CYAN);
    display_draw_text(30, 70, translate("Jour / Nuit / Mecca / ..."), COLOR_WHITE);

    display_draw_status_bar();

    if (btn_event == 3) {
        display_render_menu(); // 🔙 Retour au menu principal
    }
}



